import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We primarily use external API (TMDB), but we'll keep a simple table 
// for potential future features like watch history or favorites if needed.
export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  tmdbId: integer("tmdb_id").notNull(),
  mediaType: text("media_type").notNull(), // 'movie' or 'tv'
  title: text("title").notNull(),
  posterPath: text("poster_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBookmarkSchema = createInsertSchema(bookmarks).omit({ id: true, createdAt: true });

// --- TMDB Zod Schemas for API Type Safety ---

export const tmdbMovieSchema = z.object({
  id: z.number(),
  title: z.string(),
  original_title: z.string().optional(),
  overview: z.string(),
  poster_path: z.string().nullable(),
  backdrop_path: z.string().nullable(),
  release_date: z.string().optional(),
  vote_average: z.number(),
  runtime: z.number().optional(),
  genres: z.array(z.object({ id: z.number(), name: z.string() })).optional(),
  videos: z.object({
    results: z.array(z.object({
      key: z.string(),
      type: z.string(),
      site: z.string(),
    }))
  }).optional(),
});

export const tmdbTvSchema = z.object({
  id: z.number(),
  name: z.string(),
  original_name: z.string().optional(),
  overview: z.string(),
  poster_path: z.string().nullable(),
  backdrop_path: z.string().nullable(),
  first_air_date: z.string().optional(),
  vote_average: z.number(),
  origin_country: z.array(z.string()).optional(),
  number_of_seasons: z.number().optional(),
  seasons: z.array(z.object({
    season_number: z.number(),
    episode_count: z.number(),
    name: z.string(),
  })).optional(),
});

export const tmdbSeasonSchema = z.object({
  season_number: z.number(),
  episodes: z.array(z.object({
    id: z.number(),
    episode_number: z.number(),
    name: z.string(),
    overview: z.string(),
    still_path: z.string().nullable(),
    air_date: z.string().optional(),
  })),
});

export const tmdbEpisodeSchema = z.object({
  id: z.number(),
  episode_number: z.number(),
  name: z.string(),
  overview: z.string(),
  still_path: z.string().nullable(),
  air_date: z.string().optional(),
  vote_average: z.number().optional(),
  videos: z.object({ results: z.array(z.any()) }).optional(),
});

export const tmdbVideoSchema = z.object({
  key: z.string(),
  site: z.string(),
  type: z.string(),
});

// Response wrapper
export const tmdbSearchResponseSchema = z.object({
  results: z.array(z.union([tmdbMovieSchema, tmdbTvSchema])).optional(),
  page: z.number(),
  total_pages: z.number(),
});

export type Bookmark = typeof bookmarks.$inferSelect;
export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
export type TmdbMovie = z.infer<typeof tmdbMovieSchema>;
export type TmdbTv = z.infer<typeof tmdbTvSchema>;
