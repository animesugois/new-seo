import { z } from 'zod';
import { insertBookmarkSchema, bookmarks, tmdbMovieSchema, tmdbTvSchema, tmdbSeasonSchema, tmdbEpisodeSchema, tmdbVideoSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  tmdb: {
    trending: {
      method: 'GET' as const,
      path: '/api/tmdb/trending',
      responses: {
        200: z.object({
          results: z.array(z.any()) // Relaxed type for mixed results
        }),
      },
    },
    search: {
      method: 'GET' as const,
      path: '/api/tmdb/search',
      input: z.object({
        query: z.string(),
      }),
      responses: {
        200: z.object({
          results: z.array(z.any())
        }),
      },
    },
    movie: {
      method: 'GET' as const,
      path: '/api/tmdb/movie/:id',
      responses: {
        200: tmdbMovieSchema.extend({
          videos: z.object({ results: z.array(tmdbVideoSchema) }).optional(),
          similar: z.object({ results: z.array(z.any()) }).optional(),
        }),
      },
    },
    tv: {
      method: 'GET' as const,
      path: '/api/tmdb/tv/:id',
      responses: {
        200: tmdbTvSchema.extend({
          videos: z.object({ results: z.array(tmdbVideoSchema) }).optional(),
          similar: z.object({ results: z.array(z.any()) }).optional(),
        }),
      },
    },
    season: {
      method: 'GET' as const,
      path: '/api/tmdb/tv/:id/season/:season_number',
      responses: {
        200: tmdbSeasonSchema,
      },
    },
    episode: {
      method: 'GET' as const,
      path: '/api/tmdb/tv/:id/season/:season_number/episode/:episode_number',
      responses: {
        200: tmdbEpisodeSchema,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
