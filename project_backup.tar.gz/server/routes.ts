import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

const TMDB_API_KEY = "bd51681eae50b9c4e9ef389ce8b12771";
const TMDB_BASE_URL = "https://api.themoviedb.org/3";
const TMDB_LANG = "th-TH";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // --- TMDB Proxy Endpoints ---

  app.get(api.tmdb.trending.path, async (req, res) => {
    try {
      const response = await fetch(`${TMDB_BASE_URL}/trending/all/day?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}`);
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("TMDB Error:", error);
      res.status(500).json({ message: "Failed to fetch trending data" });
    }
  });

  app.get(api.tmdb.search.path, async (req, res) => {
    try {
      const query = req.query.query as string;
      if (!query) {
         return res.status(400).json({ message: "Query parameter is required" });
      }
      const response = await fetch(`${TMDB_BASE_URL}/search/multi?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}&query=${encodeURIComponent(query)}`);
      const data = await response.json();
      res.json(data);
    } catch (error) {
       console.error("TMDB Error:", error);
       res.status(500).json({ message: "Failed to search" });
    }
  });

  app.get(api.tmdb.movie.path, async (req, res) => {
    try {
      const id = req.params.id;
      const response = await fetch(`${TMDB_BASE_URL}/movie/${id}?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}&append_to_response=videos,similar,credits`);
      if (!response.ok) {
        return res.status(response.status).json({ message: "Movie not found" });
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
       console.error("TMDB Error:", error);
       res.status(500).json({ message: "Failed to fetch movie details" });
    }
  });

  app.get(api.tmdb.tv.path, async (req, res) => {
    try {
      const id = req.params.id;
      const response = await fetch(`${TMDB_BASE_URL}/tv/${id}?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}&append_to_response=videos,similar,credits`);
      if (!response.ok) {
        return res.status(response.status).json({ message: "TV Show not found" });
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
       console.error("TMDB Error:", error);
       res.status(500).json({ message: "Failed to fetch TV details" });
    }
  });

  app.get(api.tmdb.season.path, async (req, res) => {
    try {
      const { id, season_number } = req.params;
      const response = await fetch(`${TMDB_BASE_URL}/tv/${id}/season/${season_number}?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}`);
      if (!response.ok) {
        return res.status(response.status).json({ message: "Season not found" });
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
       console.error("TMDB Error:", error);
       res.status(500).json({ message: "Failed to fetch season details" });
    }
  });

  app.get(api.tmdb.episode.path, async (req, res) => {
    try {
      const { id, season_number, episode_number } = req.params;
      const response = await fetch(`${TMDB_BASE_URL}/tv/${id}/season/${season_number}/episode/${episode_number}?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}&append_to_response=videos`);
      if (!response.ok) {
        return res.status(response.status).json({ message: "Episode not found" });
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
       console.error("TMDB Error:", error);
       res.status(500).json({ message: "Failed to fetch episode details" });
    }
  });

  app.get("/sitemap.xml", async (req, res) => {
    try {
      const baseUrl = `https://${req.get('host')}`;
      
      // Fetch trending to get some dynamic IDs for the sitemap
      const trendingResponse = await fetch(`${TMDB_BASE_URL}/trending/all/day?api_key=${TMDB_API_KEY}&language=${TMDB_LANG}`);
      const trendingData = await trendingResponse.json();
      
      let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`;

      if (trendingData.results) {
        trendingData.results.forEach((item: any) => {
          const type = item.media_type === 'tv' ? 'tv' : 'movie';
          xml += `
  <url>
    <loc>${baseUrl}/${type}/${item.id}</loc>
    <changefreq>hourly</changefreq>
    <priority>0.8</priority>
  </url>`;
        });
      }

      xml += '\n</urlset>';
      res.header('Content-Type', 'application/xml');
      res.send(xml);
    } catch (error) {
      console.error("Sitemap Error:", error);
      res.status(500).send("Error generating sitemap");
    }
  });

  return httpServer;
}
